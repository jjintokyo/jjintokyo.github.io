FEC routines from KA9Q's libfec
===============================

This folder contains part of the libfec library by KA9Q. Only the
char-sized Reed-Solomon encoder and decoder is here.

The files have been copied from the libfec fork at
https://github.com/Opendigitalradio/ka9q-fec

Original code is at http://www.ka9q.net/code/fec/

All files in this folder are licenced under the LGPL v2.1, please see LICENCE
