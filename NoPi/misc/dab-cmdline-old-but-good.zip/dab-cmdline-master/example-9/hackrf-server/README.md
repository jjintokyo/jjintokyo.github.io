
hackrf transmitter is a simple program to generate a vhf signal.
The transmitter is separated fromany modulator, it acts as a server,
using a simple tcp connection.

It needs lots of work, e.g. specifying parameters etc.

The transmitter - when started - will show a widget with a selector
for the frequency, a button for reset (which does not do anything
right now) and a screen showing the spectrum of the signal to be transmitted.

