#!/bin/bash

stty -F /dev/ttyS0 9600 raw -echo -echoe -echok -echonl -echoctl -echoprt -noflsh

show_song_station_http="/home/pi/calcRAD/show_song_station_http";
end_of_line_character='^'

while true
do

/usr/bin/mpc idle player

status=$(cat "$show_song_station_http");
if [ "$status" == "0" ]; then continue; fi;
if [ "$status" != "0" ] && [ "$status" != "1" ] && [ "$status" != "2" ] && [ "$status" != "3" ]; then status="1"; fi;

if [ "$status" == "1" ]; then cmd=$(/usr/bin/mpc current -f %title%); echo "title = $cmd"; fi;
if [ "$status" == "2" ]; then cmd=$(/usr/bin/mpc current -f %name%);  echo "name = $cmd"; fi;
if [ "$status" == "3" ]; then cmd=$(/usr/bin/mpc current -f %file%);  echo "file = $cmd"; fi;

if [ "$cmd" == "" ]; then cmd=$(/usr/bin/mpc current -f %name%); fi;
### if [ "$cmd" == "" ]; then cmd=$(/usr/bin/mpc current -f %file%); fi;

if [ "$cmd" != "" ] && [ "$cmd" != "$old_cmd" ]; then echo "$cmd$end_of_line_character" > /dev/ttyS0; old_cmd="$cmd"; fi;

done
