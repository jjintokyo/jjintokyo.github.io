/*****************************************************************/
/*                                                               */
/*   CASIO fx-9860G SDK Library                                  */
/*                                                               */
/*   File name : calcRAD.c                                       */
/*                                                               */
/*   Copyright (c) 2006 CASIO COMPUTER CO., LTD.                 */
/*                                                               */
/*   Sat 2 Apr 2022 / JJR                                        */
/*                                                               */
/*****************************************************************/
#include "fxlib.h"

unsigned int main_timer = 0;
unsigned int mode = 1;
unsigned int preset = 0;
unsigned int volume = 10;
unsigned int last_mode = 0;
unsigned int last_preset = 0;
unsigned int smiley = 0;
unsigned int scrolling = 0;
unsigned int scroll_text_buffer_position = 0;
unsigned int scroll_text_separator = 0;
unsigned int song_station_http = 0;
unsigned char title[11] = "calcRADIO!";
unsigned char mute_desc[9] = "[ mute ]";
unsigned char blank_line_short[9] = "        ";
unsigned char blank_line_long[21] = "                    ";
unsigned char blank_line_help[27] = "                          ";
unsigned char help[7] = {0x7F, 0x50, 0x3D, 0x28, 0x2D, 0x29, 0};
unsigned char smiley1[6] = {0x28, 0x5E, 0x5F, 0x5E, 0x29, 0};
unsigned char smiley2[6] = {0x28, 0x27, 0x2E, 0x27, 0x29, 0};
unsigned char smiley3[6] = {0x28, 0x9C, 0x5F, 0x9C, 0x29, 0};
unsigned char smiley4[8] = {0x28, 0xE5, 0xCC, 0x5F, 0xE5, 0xCC, 0x29, 0};
unsigned char point[3] = {0xE5, 0xA5, 0};
unsigned char arrow[3] = {0xE6, 0x91, 0};
unsigned char bug[3] = {0xE6, 0xA6, 0};
unsigned char blank[3] = {0xE6, 0x00, 0};
unsigned char copyright[3] = {0xE5, 0x9E, 0};
unsigned char jj[3] = {0x6A, 0x6A, 0};
unsigned char mute = 0;
unsigned char do_scrolling = 0;
unsigned char shutdown = 0;
unsigned char CRLF[3] = {'\r', '\n', '\0'};
unsigned char scroll_text_buffer[256];
unsigned char scroll_text_display[21];
unsigned char mode_desc[7][21] = {"",
                                  "INTERNET RADIO #1",
                                  "INTERNET RADIO #2",
                                  "INTERNET RADIO #3",
                                  "INTERNET RADIO #4",
                                  "RANDOM INTERNET",
                                  "MP3 PLAYER"};
unsigned char preset_desc[10][6] = {"zero",
                                    "one",
                                    "two",
                                    "three",
                                    "four",
                                    "five",
                                    "six",
                                    "seven",
                                    "eight",
                                    "nine"};
unsigned char random_desc[10][12] = {"everything",
                                     "talk",
                                     "classical",
                                     "alternative",
                                     "country",
                                     "scanner",
                                     "60s",
                                     "70s",
                                     "80s",
                                     "90s"};
unsigned char help_desc_1[16][15] = {"[F1] ~ [F6]",
                                     "[0] ~ [9]",
                                     "[+] [-]",
                                     "[DEL]",
                                     "[EXE]",
                                     "[EXP]",
                                     "[->]",
                                     "[.]",
                                     "[)]",
                                     "[(]",
                                     "[^]",
                                     "[x2]",
                                     "[AC]",
                                     "[SHIFT] (Mute)",
                                     "[ALPHA] (Mute)",
                                     "[(-)]"};
unsigned char help_desc_2[16][22] = {"Set Mode",
                                     "Set Preset",
                                     "Adjust Volume",
                                     "Mute / Unmute",
                                     "Play Random Radio",
                                     "Play Special Radio",
                                     "Recall Previous",
                                     "Radio Play / Stop",
                                     "Play Next",
                                     "Play Previous",
                                     "Song / Station / http",
                                     "Speaker Test",
                                     "Calc Off",
                                     "Update DB",
                                     "Power Down",
                                     "Help"};

///////////////////////////////////////////////////////////////////
// fx legacy Syscalls                                            //
///////////////////////////////////////////////////////////////////
void RTC_Reset(unsigned int reset_mode);                         //
int RTC_GetTicks(void);                                          //
int RTC_Elapsed_ms(int start_value, int duration_in_ms);         //
int Serial_Open(unsigned char *conf);                            //
int Serial_Close(int close_mode);                                //
int Serial_IsOpen(void);                                         //
int Serial_ReadBytes(unsigned char *dest, int max, short *size); //
int Serial_WriteBytes(unsigned char *src, int size);             //
int Serial_GetRxBufferSize(void);                                //
int Serial_ClearReceiveBuffer(void);                             //
int Serial_ClearTransmitBuffer(void);                            //
int Serial_Peek(int index, unsigned char *dest);                 //
void PowerOff(int DisplayPowerOffLogo);                          //
///////////////////////////////////////////////////////////////////

/* itoa: convert n to characters in s */
void itoa(int n, char s[])
{
    int i, j, sign;
    char c;
    if ((sign = n) < 0)          /* record sign */
        n = -n;                  /* make n positive */
    i = 0;
    do {                         /* generate digits in reverse order */
        s[i++] = n % 10 + '0';   /* get next digit */
    } while ((n /= 10) > 0);     /* delete it */
    if (sign < 0)
        s[i++] = '-';
    s[i] = '\0';
    for (i = 0, j = strlen(s)-1; i < j; i++, j--) {
        c = s[i];
        s[i] = s[j];
        s[j] = c;
    }
}

void open_serial_port()
{
    unsigned char open_mode[6];
    open_mode[0] = 0;
    open_mode[1] = 5; // 0=300, 1=600, 2=1200, 3=2400, 4=4800, 5=9600, 6=19200, 7=38400, 8=57600, 9=115200 baud
    open_mode[2] = 0; // parity: 0=no; 1=odd; 2=even
    open_mode[3] = 0; // datalength: 0=8 bit; 1=7 bit
    open_mode[4] = 0; // stop bits: 0=one; 1=two
    open_mode[5] = 0;
    if (Serial_IsOpen() != 1) Serial_Open((unsigned char*)&open_mode);
}

void close_serial_port()
{
    if (Serial_IsOpen() == 1) Serial_Close(0);
}

void receive_serial_data()
{
    unsigned int status;
    unsigned int receive_buffer_size = 256;
    unsigned char end_of_line_character;
    unsigned char receive_buffer[256];
    unsigned short actual_receive_size;
    if (Serial_IsOpen() == 1 && Serial_GetRxBufferSize() > 0)
    {
        status = Serial_Peek(Serial_GetRxBufferSize() - 2, &end_of_line_character);
        if (status == 0 && end_of_line_character == '^')
        {
            status = Serial_ReadBytes((unsigned char*)&receive_buffer, receive_buffer_size, (short*)&actual_receive_size);
            if (status == 0)
            {
                receive_buffer[actual_receive_size - 2] = '\0';
                if (actual_receive_size <= 22)
                {
                    do_scrolling = 0;
                    strncpy(scroll_text_display, receive_buffer, 20);
                }
                else
                {
                    do_scrolling = 1;
                    scrolling = 0;
                    scroll_text_buffer_position = 20;
                    scroll_text_separator = 0;
                    strcpy(scroll_text_buffer, receive_buffer);
                    scroll_text_buffer[actual_receive_size - 2] = '\0';
                    strncpy(scroll_text_display, scroll_text_buffer, 20);
                }
                scroll_text_display[20] = '\0';
                PrintXY(1, 52, blank_line_long, 0);
                PrintXY(1, 52, scroll_text_display, 0);
                Bdisp_PutDisp_DD();
                Sleep(2000);
            }
            Serial_ClearReceiveBuffer();
        }
    }
}

void send_serial_data(unsigned char* operation, unsigned int parameter)
{
    unsigned char line[25];
    char string[10];
    line[0] = '\0';
    string[0] = '\0';
    strcat(line, operation);
    itoa(parameter, string);
    strcat(line, string);
    PrintXY(1, 52, blank_line_long, 0);
    PrintXY(1, 52, line, 0);
    Bdisp_PutDisp_DD();
    if (Serial_IsOpen() == 1)
    {
        Serial_ClearTransmitBuffer();
        strcat(line, CRLF);
        Serial_WriteBytes((unsigned char*)&line, strlen(line));
    }
    main_timer = RTC_GetTicks();
}

void display_mode()
{
    unsigned char line[25];
    line[0] = '\0';
    strcat(line, point);
    strcat(line, mode_desc[mode]);
    strcat(line, point);
    PrintXY(1, 14, blank_line_long, 1);
    PrintXY(1, 14, line, 1);
    PrintXY(1, 26, blank_line_long, 0);
    Bdisp_PutDisp_DD();
}

void display_preset()
{
    unsigned char line[25];
    line[0] = '\0';
    strcat(line, arrow);
    if (mode == 1 || mode == 2 || mode == 3 || mode == 4)
    {
        strcat(line, " Preset ");
        strcat(line, preset_desc[preset]);
    }
    if (mode == 5)
    {
        strcat(line, " Random ");
        strcat(line, random_desc[preset]);
    }
    if (mode == 6)
    {
        strcat(line, " Random mp3");
    }
    PrintXY(1, 26, blank_line_long, 0);
    PrintXY(1, 26, line, 0);
    Bdisp_PutDisp_DD();
}

void display_volume()
{
    unsigned char line[25];
    char string[10];
    line[0] = '\0';
    string[0] = '\0';
    strcat(line, "Vol:");
    itoa(volume, string);
    strcat(line, string);
    strcat(line, "%");
    PrintXY(1, 38, blank_line_short, 0);
    PrintXY(1, 38, line, 0);
    Bdisp_PutDisp_DD();
}

void display_mute()
{
    PrintXY(1, 38, blank_line_short, 0);
    PrintXY(1, 38, mute_desc, 1);
    Bdisp_PutDisp_DD();
}

void radio_init()
{
    RTC_Reset(1);
    main_timer = RTC_GetTicks();
    open_serial_port();
    Bdisp_AllClr_DDVRAM();
    Bdisp_AreaReverseVRAM(0, 0, 61, 10);
    Bdisp_AreaReverseVRAM(0, 11, 127, 23);
    Bdisp_DrawLineVRAM(127, 23, 127, 63);
    Bdisp_DrawLineVRAM(127, 63, 0, 63);
    Bdisp_DrawLineVRAM(0, 63, 0, 23);
    Bdisp_DrawLineVRAM(0, 47, 127, 47);
    Bdisp_DrawLineVRAM(127, 35, 108, 35);
    Bdisp_DrawLineVRAM(108, 35, 108, 47);
    PrintXY(1, 2, title, 1);
    PrintXY(64, 2, help, 0);
    PrintXY(109, 37, copyright, 0);
    PrintXY(115, 39, jj, 0);
    display_mode();
    send_serial_data((unsigned char*)"init_mode=", mode);
    display_preset();
    send_serial_data((unsigned char*)"init_preset=", preset);
    display_volume();
    send_serial_data((unsigned char*)"init_volume=", volume);
    Bdisp_PutDisp_DD();
}

void do_smiley()
{
    smiley++;
    if (smiley == 1)  { PrintXY(98, 2, smiley1, 0); Bdisp_PutDisp_DD(); return; }
    if (smiley == 6)  { PrintXY(98, 2, smiley2, 0); Bdisp_PutDisp_DD(); return; }
    if (smiley == 11) { PrintXY(98, 2, smiley3, 0); Bdisp_PutDisp_DD(); return; }
    if (smiley == 16) { PrintXY(98, 2, smiley4, 0); Bdisp_PutDisp_DD(); return; }
    if (smiley == 21)   smiley = 0;
}

void scroll_text_on_display()
{
    unsigned int i;
    if (do_scrolling)
    {
        scrolling++;
        if (scrolling == 4)
        {
            scrolling = 0;
            for (i = 0; i < 19; i++) scroll_text_display[i] = scroll_text_display[i + 1];
            if (scroll_text_buffer[scroll_text_buffer_position] == '\0')
            {
                scroll_text_display[19] = ' ';
                scroll_text_separator++;
                if (scroll_text_separator == 3)
                {
                    scroll_text_separator = 0;
                    scroll_text_buffer_position = 0;
                }
            }
            else
            {
                scroll_text_display[19] = scroll_text_buffer[scroll_text_buffer_position];
                scroll_text_buffer_position++;
            }
            scroll_text_display[20] = '\0';
            PrintXY(1, 52, blank_line_long, 0);
            PrintXY(1, 52, scroll_text_display, 0);
            Bdisp_PutDisp_DD();
        }
    }
}

void clear_scroll_text()
{
    do_scrolling = 0;
    PrintXY(1, 52, blank_line_long, 0);
    Bdisp_PutDisp_DD();
}

void set_mode(int M)
{
    mode = M;
    display_mode();
    clear_scroll_text();
    send_serial_data((unsigned char*)"set_mode=", mode);
}

void set_preset(int P)
{
    preset = P;
    display_preset();
    clear_scroll_text();
    send_serial_data((unsigned char*)"set_preset=", preset);
    last_mode = mode;
    last_preset = preset;
}

void set_volume_up()
{
    if (volume < 100)
    {
        volume += 1;
        if (volume > 100) volume=100;
        display_volume();
        send_serial_data((unsigned char*)"set_volume_up=", volume);
    }
}

void set_volume_down()
{
    if (volume > 0)
    {
        volume -= 1;
        if (volume < 0) volume=0;
        display_volume();
        send_serial_data((unsigned char*)"set_volume_down=", volume);
    }
}

void set_mute()
{
    if (mute) { mute = 0; display_volume(); }
    else      { mute = 1; display_mute();   }
    send_serial_data((unsigned char*)"set_mute=", mute);
}

void show_song_station_http()
{
    song_station_http++;
    if      (song_station_http == 1) send_serial_data((unsigned char*)"show_station=", 1);
    else if (song_station_http == 2) send_serial_data((unsigned char*)"show_http=", 1);
    else if (song_station_http == 3) { send_serial_data((unsigned char*)"show_song=", 1); song_station_http = 0; }
}

void play_random_radio()
{
    unsigned char line[25];
    mode = 5;
    display_mode();
    clear_scroll_text();
    line[0] = '\0';
    strcat(line, arrow);
    strcat(line, " play random radio");
    PrintXY(1, 26, blank_line_long, 0);
    PrintXY(1, 26, line, 0);
    Bdisp_PutDisp_DD();
    send_serial_data((unsigned char*)"init_mode=", mode);
    send_serial_data((unsigned char*)"random=", 1);
}

void play_special_radio()
{
    unsigned char line[25];
    mode = 1;
    display_mode();
    clear_scroll_text();
    line[0] = '\0';
    strcat(line, arrow);
    strcat(line, " play special radio");
    PrintXY(1, 26, blank_line_long, 0);
    PrintXY(1, 26, line, 0);
    Bdisp_PutDisp_DD();
    send_serial_data((unsigned char*)"init_mode=", mode);
    send_serial_data((unsigned char*)"special=", 1);
}

void recall_previous_preset()
{
    if (last_mode != 0) { set_mode(last_mode); set_preset(last_preset); }
}

void radio_play_stop()
{
    clear_scroll_text();
    send_serial_data((unsigned char*)"play_stop=", 1);
}

void play_next()
{
    clear_scroll_text();
    send_serial_data((unsigned char*)"play_next=", 1);
}

void play_previous()
{
    clear_scroll_text();
    send_serial_data((unsigned char*)"play_previous=", 1);
}

void speaker_test()
{
    clear_scroll_text();
    send_serial_data((unsigned char*)"speaker_test=", 1);
}

void update_database()
{
    clear_scroll_text();
    send_serial_data((unsigned char*)"update_database=", 1);
}

unsigned char sleepy_bug()
{
    unsigned int i;
    for (i = 0; i <= rand() % 255; i++)
    {
        Sleep(50);
        if (IsKeyDown(KEY_CTRL_EXE)) return 1;
    }
    return 0;
}

void show_help()
{
    unsigned int change_help_page = 200, help_page = 0, help_desc_row = 0, help_desc_index = 0, bug_x = 1, bug_y = 1;
    unsigned int help_desc_col[5] = {0, 60, 40, 33, 71};
    unsigned char bug_right = 1, bug_left = 0, bug_down = 0, bug_up = 0;
    char string[10];
    string[0] = '\0';
    srand(RTC_GetTicks());
    SaveDisp(1);
    Bdisp_AllClr_DDVRAM();
    Bdisp_DrawLineVRAM(0, 0, 127, 0);
    Bdisp_DrawLineVRAM(127, 0, 127, 63);
    Bdisp_DrawLineVRAM(127, 63, 0, 63);
    Bdisp_DrawLineVRAM(0, 63, 0, 0);
    Bdisp_DrawLineVRAM(9, 9, 118, 9);
    Bdisp_DrawLineVRAM(118, 9, 118, 54);
    Bdisp_DrawLineVRAM(118, 54, 9, 54);
    Bdisp_DrawLineVRAM(9, 54, 9, 9);
    Bdisp_AreaReverseVRAM(10, 10, 117, 15);
    Bdisp_AreaReverseVRAM(10, 48, 117, 53);
    PrintMini(12, 10, title, MINI_REV);
    PrintMini(55, 10, (unsigned char*)"v1.0", MINI_REV);
    PrintMini(91, 10, (unsigned char*)"Help( )", MINI_REV);
    PrintMini(29, 49, (unsigned char*)"Press [EXE] to exit", MINI_REV);
    while (!IsKeyDown(KEY_CTRL_EXE))
    {
        change_help_page++;
        if (change_help_page > 200)
        {
            change_help_page = 0;
            help_page++;
            if (help_page == 5) help_page = 1;
            itoa(help_page, string);
            PrintMini(110, 10, (unsigned char*)string, MINI_REV);
            for (help_desc_row = 19; help_desc_row <= 40; help_desc_row += 7)
            {
                PrintMini(12, help_desc_row, blank_line_help, MINI_OVER);
                if (help_desc_index < 16)
                {
                    PrintMini(12, help_desc_row, help_desc_1[help_desc_index], MINI_OVER);
                    PrintMini(help_desc_col[help_page], help_desc_row, help_desc_2[help_desc_index], MINI_OVER);
                }
                help_desc_index++;
            }
            if (help_desc_index > 15) help_desc_index = 0;
        }
        PrintXY(bug_x, bug_y, blank, 0);
        if (bug_right) { bug_x++; if (bug_x == 120) { if (sleepy_bug()) break; bug_x = 119; bug_right = 0; if (rand() % 2 == 0) bug_down  = 1; else bug_left  = 1; }}
        if (bug_down)  { bug_y++; if (bug_y == 56)  { if (sleepy_bug()) break; bug_y = 55;  bug_down  = 0; if (rand() % 2 == 0) bug_left  = 1; else bug_up    = 1; }}
        if (bug_left)  { bug_x--; if (bug_x == 0)   { if (sleepy_bug()) break; bug_x = 1;   bug_left  = 0; if (rand() % 2 == 0) bug_up    = 1; else bug_right = 1; }}
        if (bug_up)    { bug_y--; if (bug_y == 0)   { if (sleepy_bug()) break; bug_y = 1;   bug_up    = 0; if (rand() % 2 == 0) bug_right = 1; else bug_down  = 1; }}
        PrintXY(bug_x, bug_y, bug, 0);
        Bdisp_PutDisp_DD();
        Sleep(20);
    }
    RestoreDisp(1);
    main_timer = RTC_GetTicks();
}

void calc_off()
{
    send_serial_data((unsigned char*)"calc_off=", 1);
    close_serial_port();
    PowerOff(1);
    open_serial_port();
    send_serial_data((unsigned char*)"calc_on=", 1);
}

void shut_down()
{
    int i;
    char string[10];
    string[0] = '\0';
    shutdown = 1;
    clear_scroll_text();
    PrintXY(1, 14, blank_line_long, 1);
    PrintXY(1, 26, blank_line_long, 0);
    PrintXY(1, 38, blank_line_short, 0);
    PrintXY(1, 26, (unsigned char*)"Shutting down...", 0);
    PrintXY(1, 38, (unsigned char*)"the radio!", 0);
    send_serial_data((unsigned char*)"shutdown=", 1);
    for (i = 15; i >= 0; i--)
    {
        itoa(i, string);
        PrintXY(84, 38, (unsigned char*)"  ", 0);
        PrintXY(84, 38, (unsigned char*)string, 0);
        Bdisp_PutDisp_DD();
        Sleep(1000);
    }
}

//****************************************************************************
//  AddIn_main (Sample program main function)
//
//  param   :   isAppli   : 1 = This application is launched by MAIN MENU.
//                        : 0 = This application is launched by a strip in eACT application.
//
//              OptionNum : Strip number (0~3)
//                         (This parameter is only used when isAppli parameter is 0.)
//
//  retval  :   1 = No error / 0 = Error
//
//****************************************************************************
int AddIn_main(int isAppli, unsigned short OptionNum)
{
    radio_init();
    while (!IsKeyDown(KEY_CTRL_EXIT) && !IsKeyDown(KEY_CTRL_MENU) && !shutdown)
    {
        if (RTC_Elapsed_ms(main_timer, 500))
        {
            if (!mute)
            {
                if (IsKeyDown(KEY_CTRL_F1))       set_mode(1);
                if (IsKeyDown(KEY_CTRL_F2))       set_mode(2);
                if (IsKeyDown(KEY_CTRL_F3))       set_mode(3);
                if (IsKeyDown(KEY_CTRL_F4))       set_mode(4);
                if (IsKeyDown(KEY_CTRL_F5))       set_mode(5);
                if (IsKeyDown(KEY_CTRL_F6))       set_mode(6);
                if (IsKeyDown(KEY_CHAR_0))        set_preset(0);
                if (IsKeyDown(KEY_CHAR_1))        set_preset(1);
                if (IsKeyDown(KEY_CHAR_2))        set_preset(2);
                if (IsKeyDown(KEY_CHAR_3))        set_preset(3);
                if (IsKeyDown(KEY_CHAR_4))        set_preset(4);
                if (IsKeyDown(KEY_CHAR_5))        set_preset(5);
                if (IsKeyDown(KEY_CHAR_6))        set_preset(6);
                if (IsKeyDown(KEY_CHAR_7))        set_preset(7);
                if (IsKeyDown(KEY_CHAR_8))        set_preset(8);
                if (IsKeyDown(KEY_CHAR_9))        set_preset(9);
                if (IsKeyDown(KEY_CHAR_PLUS))     set_volume_up();
                if (IsKeyDown(KEY_CHAR_MINUS))    set_volume_down();
                if (IsKeyDown(KEY_CTRL_EXE))      play_random_radio();
                if (IsKeyDown(KEY_CHAR_EXP))      play_special_radio();
                if (IsKeyDown(KEY_CHAR_STORE))    recall_previous_preset();
                if (IsKeyDown(KEY_CHAR_DP))       radio_play_stop();
                if (IsKeyDown(KEY_CHAR_RPAR))     play_next();
                if (IsKeyDown(KEY_CHAR_LPAR))     play_previous();
                if (IsKeyDown(KEY_CHAR_SQUARE))   speaker_test();
            }
            else
            {
                if (IsKeyDown(KEY_CTRL_SHIFT))    update_database();
                if (IsKeyDown(KEY_CTRL_ALPHA))    shut_down();
            }
            if (IsKeyDown(KEY_CTRL_DEL))          set_mute();
            if (IsKeyDown(KEY_CHAR_POW))          show_song_station_http();
            if (IsKeyDown(KEY_CHAR_PMINUS))       show_help();
            if (IsKeyDown(KEY_CTRL_AC))           calc_off();
        }
        do_smiley();
        receive_serial_data();
        scroll_text_on_display();
        Sleep(100);
    }
    close_serial_port();
    Bdisp_AllClr_DDVRAM();
    return 1;
}

//****************************************************************************
//**************                                              ****************
//**************                 Notice!                      ****************
//**************                                              ****************
//**************  Please do not change the following source.  ****************
//**************                                              ****************
//****************************************************************************
#pragma section _BR_Size
unsigned long BR_Size;
#pragma section
#pragma section _TOP

//****************************************************************************
//  InitializeSystem
//
//  param   :   isAppli   : 1 = Application / 0 = eActivity
//              OptionNum : Option Number (only eActivity)
//
//  retval  :   1 = No error / 0 = Error
//
//****************************************************************************
int InitializeSystem(int isAppli, unsigned short OptionNum)
{
    return INIT_ADDIN_APPLICATION(isAppli, OptionNum);
}
#pragma section
