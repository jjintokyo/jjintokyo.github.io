#!/bin/bash

######################################
#                                    #
#              radio.sh              #
#                                    #
######################################
# RADIO / JJR / FEBRUARY 2020        #
#------------------------------------#
# PLAY                               #
#------------------------------------#
# |--> receive commands from arduino #
######################################

stty -F /dev/ttyS0 9600 raw -echo -echoe -echok -echonl -echoctl -echoprt -noflsh

preset=0; mute=0; volume=0; equal=0; adjust=0; stop=0; mode=0; show_http=0;

show_song_station_http="/home/pi/calcRAD/show_song_station_http";

random_everything="/home/pi/calcRAD/random_run.sh"; random_by_genre="/home/pi/calcRAD/random_run.py"; no_random="Nothing Found!";
speaker_test="speaker-test -Dhw:0,0 -c2 -twav &>/dev/null &";

shout0="the radio is on"; shout1="fm radio"; shout2="dab+ radio"; shout3="internet radio number one";
shout4="internet radio number two"; shout5="internet radio number three"; shout6="internet radio number four";
shout7="random internet radio"; shout8="mp3 player"; shout11="volume up"; shout12="volume down"; shout13="percent";
shout14="mute"; shout15="unmute"; shout16="volume is"; shout17="random mp3"; shout18="equalizer is on";
shout19="equalizer is off"; shout88="unknown key pressed"; shout99="shutting down the radio";
shout71="radio stopped"; shout72="radio play"; shout73="random play"; shout74="special play";

ps="preset"; p=( "zero" "one" "two" "three" "four" "five" "six" "seven" "eight" "nine" );
rd="random"; r=( "everything" "talk" "classical" "alternative" "country" "scanner" "60s" "70s" "80s" "90s" );
random=( "" "talk" "classical" "alternative" "country" "scanner" "60s" "70s" "80s" "90s" );

SoundOn()           { /usr/bin/amixer cset numid=2 on &>/dev/null; }
SoundOff()          { /usr/bin/amixer cset numid=2 off &>/dev/null; }
SetVolume()         { /usr/bin/amixer cset numid=1 "$1"% &>/dev/null; }
SayMode()           { if [ "$1" -eq 1 ]; then shout="$shout3"; adjust=0; elif [ "$1" -eq 2 ]; then shout="$shout4"; adjust=10; elif [ "$1" -eq 3 ]; then shout="$shout5"; adjust=20; elif [ "$1" -eq 4 ]; then shout="$shout6"; adjust=30; elif [ "$1" -eq 5 ]; then shout="$shout7"; elif [ "$1" -eq 6 ]; then shout="$shout8"; fi; }
Talk2Me()           { flite -o flite.wav -t "$1" -voice slt --setf duration_stretch=.9 --setf int_f0_target_mean=237 &>/dev/null && aplay flite.wav -D"equal" &>/dev/null; }
stop_radio()        { /usr/bin/mpc stop &>/dev/null; sudo pkill vlc; sudo pkill speaker-test; stop=1; }
radio_play_stop()   { if [ "$stop" -eq 0 ]; then stop_radio; Talk2Me "$shout71"; else Talk2Me "$shout72"; stop=0;
                      if [ "$mode" -ne 6 ]; then /usr/bin/mpc play &>/dev/null; send_play; else play_mp3; fi; fi; }
play_preset()       { if [ "$mode" -eq 1 ] || [ "$mode" -eq 2 ] || [ "$mode" -eq 3 ] || [ "$mode" -eq 4 ]; then
                      if [ "$stop" -eq 1 ]; then Talk2Me "play preset $preset from page $mode"; else stop_radio; fi;
                       /usr/bin/mpc play "$((($preset+(($mode-1))*10)+1))" &>/dev/null; send_play; stop=0;
                       elif [ "$mode" -eq 5 ]; then random_by_genre "$1";
                       elif [ "$mode" -eq 6 ]; then play_mp3; fi; }
play_next()         { if [ "$stop" -eq 0 ] && [ "$mode" -ne 6 ]; then /usr/bin/mpc next &>/dev/null; send_play; else say_time; fi; }
play_previous()     { if [ "$stop" -eq 0 ] && [ "$mode" -ne 6 ]; then /usr/bin/mpc prev &>/dev/null; send_play; else say_time; fi; }
random_everything() { if [ "$stop" -eq 1 ]; then Talk2Me "$shout73"; else stop_radio; fi; url=$("$random_everything");
                      if [ "$url" == "$no_random" ]; then stop=1; Talk2Me "$no_random"; else send_play; stop=0; /bin/echo "$url"; fi; }
random_by_genre()   { what_say_genre; if [ "$stop" -eq 1 ]; then Talk2Me "play random $say"; else stop_radio; fi;
                      while true; do url=$("$random_by_genre" "$genre");
                          if [ "$url" == "$no_random" ] || [ "$url" == "" ]; then stop=1; Talk2Me "$no_random"; break; fi;
                          /usr/bin/mpc del 41 &>/dev/null;
                          /usr/bin/mpc add "$url" &>/dev/null;
                          /usr/bin/mpc play 41 &>/dev/null;
                          ok=$(/bin/echo $?); /bin/sleep 1; status=$(/usr/bin/mpc status);
                          if ! /bin/echo "$status" | /bin/grep -q "ERROR: Failed" && [ "$ok" -eq 0 ]; then send_play; stop=0; /bin/echo "$url"; break; fi;
                       done; }
what_say_genre()    { say=""; genre=""; say=${r[$preset]}; genre=${random[$preset]}; }
play_mp3()          { Talk2Me "$shout17"; vlc -I dummy --alsa-audio-device equal -LZ "/home/pi/mp3" </dev/null &>/dev/null & }
say_time()          { if [ "$stop" -eq 1 ]; then h=$(date +'%H'); m=$(date +'%M'); s=$(date +'%S');
                      if [ "$h" -gt 1 ]; then hour="hours"; else hour="hour"; fi;
                      if [ "$m" -gt 1 ]; then minute="minutes"; else minute="minute"; fi;
                      if [ "$s" -gt 1 ]; then second="seconds"; else second="second"; fi;
                      Talk2Me "the time is $h $hour $m $minute and $s $second"; fi; }
send_play()         { col=""; }; ## /bin/sleep 2; if [ "$show_http" -eq 0 ]; then info=$(/usr/bin/mpc current);
                                 ## else info=$(/usr/bin/mpc current -f %file%); fi; echo "$info" > /dev/ttyS0; }

stop_radio; /usr/bin/mpc clear &>/dev/null; /bin/cat /home/pi/calcRAD/playlist.db | /usr/bin/mpc add &>/dev/null; /usr/bin/mpc repeat on &>/dev/null;

cat -v /dev/ttyS0 | while read data; do
  operation="${data%=*}"
  parameter="${data#*=}"
##  echo "operation = $operation ; parameter = $parameter"
##  echo ""
  case "${operation}" in

    $"init_mode")       value="$((parameter * 1))"; mode="$value";   stop_radio;;
    $"init_preset")     value="$((parameter * 1))"; preset="$value"; stop_radio;;
    $"init_volume")     value="$((parameter * 1))"; volume="$value"; SoundOn; SetVolume "$volume";;

    $"set_mode")        value="$((parameter * 1))"; mode="$value";   stop_radio; SayMode "$mode"; Talk2Me "$shout";;
    $"set_preset")      value="$((parameter * 1))"; preset="$value"; stop_radio; play_preset;;
    $"set_volume_up")   value="$((parameter * 1))"; volume="$value"; SetVolume "$volume"; Talk2Me "$shout11 $volume $shout13";;
    $"set_volume_down") value="$((parameter * 1))"; volume="$value"; SetVolume "$volume"; Talk2Me "$shout12 $volume $shout13";;
    $"set_mute")        value="$((parameter * 1))"; mute="$value";
                        if [ "$mute" -eq 1 ]; then SayMode "$mode"; Talk2Me "$shout14 $shout"; SoundOff;
                        else SoundOn; SayMode "$mode"; Talk2Me "$shout15 $shout $shout16 $volume $shout13"; fi;;
    $"random")          random_everything;;
    $"special")         if [ "$stop" -eq 1 ]; then Talk2Me "$shout74"; else stop_radio; fi;
                        url=$(cat /home/pi/calcRAD/special.db);
                        /usr/bin/mpc del 41 &>/dev/null;
                        /usr/bin/mpc add "$url" &>/dev/null;
                        /usr/bin/mpc play 41 &>/dev/null;
                        send_play; stop=0;;
    $"play_stop")       radio_play_stop;;
    $"play_next")       play_next;;
    $"play_previous")   play_previous;;
    $"speaker_test")    stop_radio; eval "$speaker_test"; stop=0;;

    $"show_song")       echo "1" > "$show_song_station_http";;
    $"show_station")    echo "2" > "$show_song_station_http";;
    $"show_http")       echo "3" > "$show_song_station_http";;

    $"calc_off")        echo "0" > "$show_song_station_http";;
    $"calc_on")         echo "1" > "$show_song_station_http";;

    $"shutdown")        stop_radio; sleep 0.5; SoundOn; Talk2Me "$shout99"; SoundOff; sudo shutdown now;;
    *)                  if [ "$mute" -eq 0 ]; then Talk2Me "$shout88"; fi;;
  esac
done
