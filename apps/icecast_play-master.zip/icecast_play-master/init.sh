curl -H "Content-Length: 0" -H "X-Requested-With: XMLHttpRequest"  -X POST http://www.shoutcast.com/Home/Top -o shoutcast.json
curl http://dir.xiph.org/yp.xml -o yp.xml
