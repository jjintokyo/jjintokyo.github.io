#!/bin/sh

help2man \
  --name "DAB/DAB+ Software Radio" \
  --no-info \
  --output welle-io.1 \
  welle-io
